exports.getPosts = (req,res,next) => {
    res.status(200).json(
        {
            posts: [
                {title:"Primer Post",content:"este es mi primer post"},
                {title:"Segundo Post",content:"este es mi Segundo post"}
            ],
        })
}
exports.createPost = (req,res,next) => {
     
         
    const title = req.body.title;
    const content = req.body.content;
    console.log("juanito" +req)
    console.log(req)
    res.status(201).json(
        {
            message:"se creo correctamente",
            post:{id:new Date().toDateString(),title:title,content:content}
        }
    )
    console.log("juanito")
  
    
}