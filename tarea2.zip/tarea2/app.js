const http = require("http");
const index = require("./index");
const server = http.createServer(index.requestHandler);
server.listen(800);