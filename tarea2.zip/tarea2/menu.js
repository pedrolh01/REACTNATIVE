function Main_menu(){ 
     var menu = "";
     menu += "<ul>";
     menu += "<li><a href='/'>HOME</a></li>";
     menu += "<li><a href='/user'>USER</a></li>";
     menu += "<li><a href='/book'>BOOK</a></li>"; 
     menu += "</ul>";
     
    return menu.toString(); 
}
function User_menu(){ 
    var menu = ""; 
    menu += "--<strong><a href='/user/create'>create</a></strong>--";
    menu += "--<strong><a href='/user/show'>show</a></strong>--";  
    
   return menu.toString(); 
}
function Book_menu(){ 
    var menu = ""; 
    menu += "--<strong><a href='/book/create'>create</a></strong>--";
    menu += "--<strong><a href='/book/show'>show</a></strong>--";  
    
   return menu.toString(); 
} 

module.exports = {
    Main_menu: Main_menu,
    User_menu: User_menu,
    Book_menu: Book_menu,
    mensaje:"menu",
};