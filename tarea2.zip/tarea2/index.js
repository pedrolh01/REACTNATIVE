//IMPORTA LIBRERIAS
const fs    = require("fs");
const http = require("http");
const user = require("./user");
const book = require("./book");
const menu = require("./menu");
const utf8 = require('utf8');

const requestHandler = (rq,res) => {
    console.log(rq.url,rq.method,rq.headers);
    const url = rq.url;
    const method = rq.method;
    if(url === "/"){
        index(rq,res)
    }else if(url === "/user" && method === "GET"){ 
        user.index(rq,res) 
    }
    else if(url === "/user/create" && method === "GET"){
        user.form(rq,res) 
    }
    else if(url === "/user/add" && method === "POST"){
        user.add(rq,res) 
    }
    else if(url === "/user/created" && method === "GET"){
        user.created(rq,res) 
    }else if(url === "/user/show" && method === "GET"){
        user.show(rq,res) 
    }
    else if(url === "/book" && method === "GET"){ 
        book.index(rq,res) 
    }
    else if(url === "/book/create" && method === "GET"){
        book.form(rq,res) 
    }
    else if(url === "/book/add" && method === "POST"){
        book.add(rq,res) 
    }
    else if(url === "/book/created" && method === "GET"){
        book.created(rq,res) 
    }else if(url === "/book/show" && method === "GET"){
        book.show(rq,res) 
    }
} 

function index(rq,res){

    res.setHeader("Content-Type","text/html");
    res.write("<html>");
    res.write("<head>");
    res.write("<title>Home</title>");
    res.write("</head>");
    res.write("<body>");
    res.write("<div>");
    res.write("<h1>Bienvenido</h1>");
    res.write("<img src='https://image.flaticon.com/icons/png/512/190/190634.png' style='width: 35px;'></img>");
    res.write(menu.Main_menu());
    res.write("<div>");
    res.write("</body>");
    res.write("</html>");
    return res.end();

} 
module.exports = {
    requestHandler: requestHandler, 
    mensaje:"user module",
};