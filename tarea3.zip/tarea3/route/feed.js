const express = require("express"); 
const router = express.Router();

const indexController = require("../controllers/index");
const userController = require("../controllers/user");
const bookController = require("../controllers/book"); 

//home
router.get("/",indexController.requestHandler); 
//user
router.get("/user",userController.index); 
router.get("/user/show",userController.show); 
router.get("/user/create",userController.form); 
router.get("/user/created",userController.created);
router.post("/user/add",userController.add); 
//book
router.get("/book",bookController.index); 
router.get("/book/show",bookController.show); 
router.get("/book/create",bookController.form); 
router.get("/book/created",bookController.created);
router.post("/book/add",bookController.add); 

module.exports = router;