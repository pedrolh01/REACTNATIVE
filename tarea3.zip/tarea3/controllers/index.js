function requestHandler(req,res,next){ 
    res.render('layouts/home/index'); 
} 
module.exports = {
    requestHandler: requestHandler, 
    mensaje:"index module",
};