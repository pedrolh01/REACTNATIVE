const fs    = require("fs"); 
var user = {
    id: "id",
    first_name: "first_name",
    last_name: "last_name",
    marital_status: "marital_status",
    join_date: "join_date"
  };
var userArr = []
function form(rq,res){  
    res.render('layouts/user/form');  
}
function index(rq,res){
    res.render('layouts/user/index'); 
}
function add(rq,res,next){
    const body = [];
        rq.on("data",(chunk) => {
            console.log(chunk);
            body.push(chunk);
        });
        rq.on("end",() => {
            const completedBody = Buffer.concat(body).toString();
            //const message = completedBody.split("=")[1];
            user.id = completedBody.split("=")[1].substring(0,completedBody.split("=")[1].indexOf('&'));
            user.first_name = completedBody.split("=")[2].substring(0,completedBody.split("=")[2].indexOf('&'));
            user.last_name = completedBody.split("=")[3].substring(0,completedBody.split("=")[3].indexOf('&'));
            user.marital_status = completedBody.split("=")[4].substring(0,completedBody.split("=")[4].indexOf('&'));
            user.join_date = completedBody.split("=")[5];

            if  (read().length == 0){
                userArr = []
                userArr.push(user)
            }else{
                userArr = JSON.parse(read());
                userArr.push(user)
            }
            console.log(completedBody);
            fs.writeFileSync ("db_user.txt",JSON.stringify(userArr)); 
            res.statusCode=302;
            res.setHeader("Location","/user/created"); 
            console.log("archivo escrito");
            return res.end();
        });
    console.log("added")
}
function read(){ 
    return fs.readFileSync("db_user.txt").toString() 
}
function show(rq,res){ 
    if  (read().length == 0){ 
        res.render('layouts/user/show',{data:null,title:"User"}); 
    }else{
        userArr = JSON.parse(read());
        res.render('layouts/user/show',{data:userArr,title:"User"}); 
    }  
}  
function created(rq,res){ 
    res.render('layouts/user/created');   
}
module.exports = {
    form: form, 
    index : index,
    show : show,
    add : add,
    created :created,
    mensaje:"user module",
};