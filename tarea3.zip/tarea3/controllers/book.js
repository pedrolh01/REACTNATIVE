const fs    = require("fs");  
var book = {
    id: "John",
    name: "John",
    author: "Doe",
    publishDate: 50,
    description: "blue"
  };
  var bookArr = []
  function form(rq,res){  
    res.render('layouts/book/form');  
}
function index(rq,res){
    res.render('layouts/book/index'); 
} 
function add(rq,res,next){
    const body = [];
    rq.on("data",(chunk) => {
        console.log(chunk);
        body.push(chunk);
    });
    rq.on("end",() => {
        const completedBody = Buffer.concat(body).toString();
        //const message = completedBody.split("=")[1];
        book.id = completedBody.split("=")[1].substring(0,completedBody.split("=")[1].indexOf('&'))
        book.name = completedBody.split("=")[2].substring(0,completedBody.split("=")[2].indexOf('&'))
        book.author = completedBody.split("=")[3].substring(0,completedBody.split("=")[3].indexOf('&'))
        book.publishDate = completedBody.split("=")[4].substring(0,completedBody.split("=")[4].indexOf('&'))
        book.description = completedBody.split("=")[5]

        if  (read().length == 0){
            bookArr = []
            bookArr.push(book)
        }else{
            bookArr = JSON.parse(read());
            bookArr.push(book)
        }
        console.log(completedBody);
        fs.writeFileSync ("db_book.txt",JSON.stringify(bookArr));
        
        res.statusCode=302;
        res.setHeader("Location","/book/created"); 
        return res.end();
        console.log("archivo escrito"); 
    });
    console.log("added")
}
function read(){ 
    return fs.readFileSync("db_book.txt").toString() 
}function show(rq,res){ 
    if  (read().length == 0){ 
        res.render('layouts/book/show',{data:null,title:"book"}); 
    }else{
        userArr = JSON.parse(read());
        res.render('layouts/book/show',{data:userArr,title:"book"}); 
    }  
}  
function created(rq,res){ 
    res.render('layouts/book/created');   
}
module.exports = {
    form: form, 
    index : index,
    show : show,
    add : add,
    created :created,
    mensaje:"book module",
};