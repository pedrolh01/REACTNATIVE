//IMPORTA LIBRERIAS
const fs    = require("fs");
const http = require("http");
const menu = require("./menu");
const utf8 = require('utf8');

var book = {
    id: "John",
    name: "John",
    author: "Doe",
    publishDate: 50,
    description: "blue"
  };
  var bookArr = []
function form(rq,res){

    res.setHeader("Content-Type","text/html; charset=utf-8");
    res.write("<html>");
    res.write("<head>");
    res.write("<title>BOOK</title>");
    res.write("</head>");
    res.write("<body>");
    res.write("<h1>Create Book</h1>");
    res.write(menu.Main_menu());
    res.write(menu.Book_menu());
    res.write("<form action='/book/add' method='post'>");
    res.write("<input name='id' placeholder='id'></input><br>");
    res.write("<input name='name' placeholder='name'></input><br>");
    res.write("<input name='author' placeholder='author'></input><br>");
    res.write("<input type='date' name='publishDate' placeholder='publishDate'></input><br>");
    res.write("<input name='description' placeholder='description'></input><br>");
    res.write("<button>enviar</button></form></button>"); 
    res.write("</body>");
    res.write("</html>");
    return res.end();

}
function index(rq,res){

    res.setHeader("Content-Type","text/html; charset=utf-8");
    res.write("<html>");
    res.write("<head>");
    res.write("<title>Index Book</title>");
    res.write("</head>");
    res.write("<body>");
    res.write("<h1>Index Book</h1>");
    res.write(menu.Main_menu());
    res.write(menu.Book_menu()); 
    res.write("</body>");
    res.write("</html>");
    return res.end();

}
function add(rq,res){
    const body = [];
    rq.on("data",(chunk) => {
        console.log(chunk);
        body.push(chunk);
    });
    rq.on("end",() => {
        const completedBody = Buffer.concat(body).toString();
        //const message = completedBody.split("=")[1];
        book.id = utf8.encode(completedBody.split("=")[1].substring(0,completedBody.split("=")[1].indexOf('&')));
        book.name = utf8.encode(completedBody.split("=")[2].substring(0,completedBody.split("=")[2].indexOf('&')));
        book.author = utf8.encode(completedBody.split("=")[3].substring(0,completedBody.split("=")[3].indexOf('&')));
        book.publishDate = utf8.encode(completedBody.split("=")[4].substring(0,completedBody.split("=")[4].indexOf('&')));
        book.description = utf8.encode(completedBody.split("=")[5]);

        if  (read().length == 0){
            bookArr = []
            bookArr.push(book)
        }else{
            bookArr = JSON.parse(read());
            bookArr.push(book)
        }
        console.log(completedBody);
        fs.writeFileSync ("db_book.txt",JSON.stringify(bookArr));
        
        res.statusCode=302;
        res.setHeader("Location","/book/created"); 
        console.log("archivo escrito");
        return res.end();
    });
console.log("add")
}
function read(){ 
    return fs.readFileSync("db_book.txt").toString() 
}
function show(rq,res){
        res.setHeader("Content-Type","text/html; charset=utf-8");
        res.write("<html>");
        res.write("<head>");
        res.write("<title>Show Book</title>");
        res.write("</head>");
        res.write("<body>");
        res.write("<h1>Show Book</h1>");
        res.write(menu.Main_menu());
        res.write(menu.Book_menu()); 
    if  (read().length == 0){
        res.write("<p>No hay data. <a href='/book/create'>create</a></p>"); 
    }else{
        res.write("<table>");
        res.write("<tr>");
        res.write("<td>ID</td>");
        res.write("<td>name</td>");
        res.write("<td>author</td>");
        res.write("<td>publishDate</td>");
        res.write("<td>description</td>");
        res.write("<td>img</td>");
        res.write("</tr>");
        userArr = JSON.parse(read());
        userArr.forEach( function (item, index) {
            res.write("<tr>");
            res.write("<td>"+item.id+"</td>");
            res.write("<td>"+item.name+"</td>");
            res.write("<td>"+item.author+"</td>");
            res.write("<td>"+item.publishDate+"</td>");
            res.write("<td>"+item.description+"</td>");
            res.write("<td><img src='https://banner2.kisspng.com/20180701/egi/kisspng-book-download-clip-art-5b39000b5f63a3.4016891515304622193907.jpg' style='width: 35px;'></img></td>");
            res.write("</tr>"); 
        });
        res.write("</table>");
    }
    res.write("</body>");
    res.write("</html>");
    return res.end();
    
    
} 
function created(rq,res){

    res.setHeader("Content-Type","text/html; charset=utf-8");
    res.write("<html>");
    res.write("<head>");
    res.write("<title>Created Book</title>");
    res.write("</head>");
    res.write("<body>");
    res.write("<h1>Created Success</h1>"); 
    res.write(menu.Main_menu());
    res.write(menu.Book_menu()); 
    res.write("</body>");
    res.write("</html>");
    return res.end();

}
module.exports = {
    form: form, 
    index : index,
    show : show,
    add : add,
    created :created,
    mensaje:"book module",
};