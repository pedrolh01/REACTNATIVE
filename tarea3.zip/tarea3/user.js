//IMPORTA LIBRERIAS
const fs    = require("fs");
const http = require("http");
const menu = require("./menu");
const utf8 = require('utf8');

var user = {
    id: "id",
    first_name: "first_name",
    last_name: "last_name",
    marital_status: "marital_status",
    join_date: "join_date"
  };
var userArr = []
function form(rq,res){

    res.setHeader("Content-Type","text/html; charset=utf-8");
    res.write("<html>");
    res.write("<head>");
    res.write("<title>USER</title>");
    res.write("</head>");
    res.write("<body>");
    res.write("<h1>Create User</h1>");
    res.write(menu.Main_menu());
    res.write(menu.User_menu());
    res.write("<form action='/user/add' method='post'>");
    res.write("<input name='id' placeholder='id'></input><br>");
    res.write("<input name='first_name' placeholder='first_name'></input><br>");
    res.write("<input name='last_name' placeholder='last_name'></input><br>");
    res.write("<input name='marital_status' placeholder='marital_status'></input><br>");
    res.write("<input type='date' name='join_date' placeholder='join_date'></input><br>");
    res.write("<button>enviar</button></form></button>"); 
    res.write("</body>");
    res.write("</html>");
    return res.end();

}
function index(rq,res){

    res.setHeader("Content-Type","text/html; charset=utf-8");
    res.write("<html>");
    res.write("<head>");
    res.write("<title>Index User</title>");
    res.write("</head>");
    res.write("<body>");
    res.write("<h1>Index User</h1>");
    res.write(menu.Main_menu());
    res.write(menu.User_menu());    
    res.write("</body>");
    res.write("</html>");
    return res.end();

}
function add(rq,res){
    const body = [];
        rq.on("data",(chunk) => {
            console.log(chunk);
            body.push(chunk);
        });
        rq.on("end",() => {
            const completedBody = Buffer.concat(body).toString();
            //const message = completedBody.split("=")[1];
            user.id = completedBody.split("=")[1].substring(0,completedBody.split("=")[1].indexOf('&'));
            user.first_name = completedBody.split("=")[2].substring(0,completedBody.split("=")[2].indexOf('&'));
            user.last_name = completedBody.split("=")[3].substring(0,completedBody.split("=")[3].indexOf('&'));
            user.marital_status = completedBody.split("=")[4].substring(0,completedBody.split("=")[4].indexOf('&'));
            user.join_date = completedBody.split("=")[5];

            if  (read().length == 0){
                userArr = []
                userArr.push(user)
            }else{
                userArr = JSON.parse(read());
                userArr.push(user)
            }
            console.log(completedBody);
            fs.writeFileSync ("db_user.txt",JSON.stringify(userArr));
            
            res.statusCode=302;
            res.setHeader("Location","/user/created"); 
            console.log("archivo escrito");
            return res.end();
        });
    console.log("add")
}
function read(){ 
    return fs.readFileSync("db_user.txt").toString() 
}
function show(rq,res){ 
    res.setHeader("Content-Type","text/html; charset=utf-8");
        res.write("<html>");
        res.write("<head>");
        res.write("<title>Show User</title>");
        res.write("</head>");
        res.write("<body>");
        res.write("<h1>Show User</h1>");
        res.write(menu.Main_menu());
        res.write(menu.User_menu());
    if  (read().length == 0){
        res.write("<p>No hay data. <a href='/user/create'>create</a></p>"); 
    }else{
        res.write("<table>");
        res.write("<tr>");
        res.write("<td>ID</td>");
        res.write("<td>first_name</td>");
        res.write("<td>last_name</td>");
        res.write("<td>marital_status</td>");
        res.write("<td>join_date</td>");
        res.write("<td>img</td>");
        res.write("</tr>");
        userArr = JSON.parse(read());
        userArr.forEach( function (item, index) {
            res.write("<tr>");
            res.write("<td>"+item.id+"</td>");
            res.write("<td>"+item.first_name+"</td>");
            res.write("<td>"+item.last_name+"</td>");
            res.write("<td>"+item.marital_status+"</td>");
            res.write("<td>"+item.join_date+"</td>");
            res.write("<td><img src='https://image.flaticon.com/icons/png/512/190/190634.png' style='width: 35px;'></img></td>");
            res.write("</tr>"); 
        });
        res.write("</table>");
    }
    res.write("</body>");
    res.write("</html>");
    return res.end();
    
    
}  
function created(rq,res){ 
    res.setHeader("Content-Type","text/html; charset=utf-8");
    res.write("<html>");
    res.write("<head>");
    res.write("<title>Created User</title>");
    res.write("</head>");
    res.write("<body>");
    res.write("<h1>Created Success</h1>"); 
    res.write(menu.Main_menu());
    res.write(menu.User_menu());
    res.write("</body>");
    res.write("</html>");
    return res.end();
}
module.exports = {
    form: form, 
    index : index,
    show : show,
    add : add,
    created :created,
    mensaje:"user module",
};